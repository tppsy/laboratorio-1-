% Script para barrido de frecuencia en Simulink (Actividad 1)
frecuencias = logspace(1, 6, 10); % 10 puntos entre 10 Hz y 1 MHz
capacitancias = [0, 10e-6, 1000e-6]; % Sin C, 10uF, 1000uF
R = 10000; % Resistencia de 10k ohms

% Crear tabla para almacenar resultados
resultados = [];

for c = capacitancias
    for f = frecuencias
        % Asignar variables al workspace para Simulink
        f_val = f;
        c_val = c;
        
        % Ajustar el tiempo de simulación para capturar al menos 5 ciclos
        T = 1 / f;
        t_sim = 5 * T;
        
        % Ejecutar simulación (reemplazar 'modelo_actividad1' por el nombre de tu archivo .slx)
        simOut = sim('lab_bioelectronica1', 'StopTime', num2str(t_sim));
        
        % Extraer señal de salida Vo
        Vo = simOut.Vo_signal.Data; 
        
        % Cálculos de parámetros
        Vpeak = max(Vo);
        Vpp = max(Vo) - min(Vo);
        Vrms = rms(Vo);
        Vmedio = mean(Vo);
        Irms = Vrms / R;
        
        % Guardar datos
        resultados = [resultados; c, f, Vpeak, Vpp, Vrms, Vmedio, Irms];
    end
end
% Convertir la matriz de resultados a un archivo fácil de manipular
% Columnas de 'resultados': [C, Frecuencia, Vpeak, Vpp, Vrms, Vmedio, Irms]

% Extraer vectores según el valor del capacitor
idx_sinC  = resultados(:, 1) == 0;
idx_C10u  = resultados(:, 1) == 10e-6;
idx_C1000 = resultados(:, 1) == 1000e-6;

f_vec = resultados(idx_sinC, 2); % Frecuencias utilizadas

% ----------------------------------------------------
% Figura 1: Comparación del Voltaje Medio (DC) vs Frecuencia
% ----------------------------------------------------
figure('Name', 'Respuesta en Frecuencia - Voltaje Medio');
semilogx(f_vec, resultados(idx_sinC, 6), '-o', 'LineWidth', 1.5, 'DisplayName', 'Sin Capacitor');
hold on;
semilogx(f_vec, resultados(idx_C10u, 6), '-s', 'LineWidth', 1.5, 'DisplayName', 'C = 10 \muF');
semilogx(f_vec, resultados(idx_C1000, 6), '-^', 'LineWidth', 1.5, 'DisplayName', 'C = 1000 \muF');
hold off;

grid on;
xlabel('Frecuencia (Hz)');
ylabel('Voltaje Medio V_{medio} (V)');
title('Voltaje Medio de Salida V_o vs. Frecuencia');
legend('Location', 'northeast');

% ----------------------------------------------------
% Figura 2: Comparación del Voltaje Pico a Pico (Rizado) vs Frecuencia
% ----------------------------------------------------
figure('Name', 'Respuesta en Frecuencia - Rizado (Vpp)');
semilogx(f_vec, resultados(idx_sinC, 4), '-o', 'LineWidth', 1.5, 'DisplayName', 'Sin Capacitor');
hold on;
semilogx(f_vec, resultados(idx_C10u, 4), '-s', 'LineWidth', 1.5, 'DisplayName', 'C = 10 \muF');
semilogx(f_vec, resultados(idx_C1000, 4), '-^', 'LineWidth', 1.5, 'DisplayName', 'C = 1000 \muF');
hold off;

grid on;
xlabel('Frecuencia (Hz)');
ylabel('Voltaje Pico a Pico V_{p-p} (V)');
title('Rizado de Salida V_{p-p} vs. Frecuencia');
legend('Location', 'northeast');

% ----------------------------------------------------
% Figura 3: Subplots con todas las variables para un caso específico (ej. C = 10 uF)
% ----------------------------------------------------
figure('Name', 'Analisis Completo C = 10 uF');

subplot(2,2,1);
semilogx(f_vec, resultados(idx_C10u, 3), '-o', 'Color', 'b');
grid on; xlabel('Frecuencia (Hz)'); ylabel('Voltaje (V)'); title('V_{peak}');

subplot(2,2,2);
semilogx(f_vec, resultados(idx_C10u, 5), '-o', 'Color', 'r');
grid on; xlabel('Frecuencia (Hz)'); ylabel('Voltaje (V)'); title('V_{rms}');

subplot(2,2,3);
semilogx(f_vec, resultados(idx_C10u, 6), '-o', 'Color', 'g');
grid on; xlabel('Frecuencia (Hz)'); ylabel('Voltaje (V)'); title('V_{medio}');

subplot(2,2,4);
semilogx(f_vec, resultados(idx_C10u, 7)*1000, '-o', 'Color', 'm'); % En mA
grid on; xlabel('Frecuencia (Hz)'); ylabel('Corriente (mA)'); title('I_{rms}');
%% voltaje respecto al tiempo
frecuencias = [10, 1e3, 1e6];
for i = 1:length(frecuencias)
% Script para graficar Vo(t) respecto al tiempo para f = 1 kHz
f_test = frecuencias(i); % Frecuencia de prueba en Hz
T = 1 / f_test; % Periodo de la señal
t_sim = 4 * T; % Simular 4 ciclos para apreciar bien la forma de onda

capacitancias = [0, 10e-6, 1000e-6]; % Sin C, 10uF, 1000uF
etiquetas = {'Sin Capacitor', 'C = 10 \muF', 'C = 1000 \muF'};
colores = {'b', 'r', 'g'};

figure('Name', 'Forma de Onda de Vo respecto al Tiempo');

for i = 1:length(capacitancias)
    c_val = capacitancias(i);
    f_val = f_test;
    
    % Correr simulación
    set_param('lab_bioelectronica1', 'StopTime', num2str(t_sim));
    set_param('lab_bioelectronica1', 'MaxStep', num2str(T/50)); % Paso máximo de 20 ns
    simOut = sim('lab_bioelectronica1');
    
    % Extraer tiempo y voltaje
    t = simOut.Vo_signal.Time;
    Vo = simOut.Vo_signal.Data;
    
    % Graficar la señal
    plot(t * 1e6, Vo, 'LineWidth', 1.5, 'Color', colores{i}, 'DisplayName', etiquetas{i});
    hold on;
end


hold off;
grid on;
xlabel('Tiempo (\mus)');
ylabel('Voltaje de Salida V_o (V)');
title(['Voltaje de Salida V_o(t) vs. Tiempo (f = ' num2str(f_test) ' Hz)']);
legend('Location', 'northeast');
end